# README — Análisis Automatizado de Sentimiento de Tweets
## Proyecto Final — AI Automation | Coderhouse
**Alumno:** Diego Rosolen  
**Comisión:** 97345  
**Profesor:** Ezequiel Matias Tartaglia

---

## Descripción

Workflow automatizado en n8n que analiza el sentimiento de tweets cargados en Google Sheets.
Clasifica cada tweet como POSITIVO, NEGATIVO o NEUTRAL usando Gemini 2.5 Flash, y para los
negativos genera un análisis detallado con Gemini 2.5 Pro y envía una alerta por email.

---

## Requisitos previos

- n8n v2.6.3 Self Hosted (o superior)
- Cuenta de Google con acceso a Google Sheets
- API Key de Google AI Studio (Gemini) — obtener gratis en https://aistudio.google.com
- Cuenta de Gmail con contraseña de aplicación de 16 caracteres habilitada y doble factor de authenticacion 

---

## Estructura de archivos

```
proyecto-final/
├── workflow.json               # Workflow exportado de n8n
├── prompts.txt                 # Prompts usados en cada nodo LLM
├── README.md                   # Este archivo
├── documentacion.pdf           # Descripción técnica, diagramas y configuración
└── evidencias/
    ├── clasificador_3_tweets.png   # Output del clasificador con POSITIVO/NEGATIVO/NEUTRAL
    ├── inbox_mails_negativos.png   # Inbox con los 2 mails recibidos
    ├── mail_negativo_alto.png      # Mail completo severidad ALTA
    └── mail_negativo_bajo.png      # Mail completo severidad BAJA
```

---

## Pasos para importar y ejecutar

### 1. Importar el workflow en n8n
1. Abrí n8n → menú **Workflows** → **Import from File**
2. Seleccioná el archivo `workflow.json`
3. El flujo va a aparecer con todos los nodos configurados

### 2. Crear la Google Sheet
1. Creá una hoja de cálculo en Google Sheets
2. Nombrá la hoja como **Hoja 1**
3. Creá exactamente estas columnas en la fila 1:
   - `tweet_text`
   - `autor`
   - `fecha`

### 3. Configurar credenciales de Google Sheets
1. En n8n → **Credentials** → **New** → **Google Sheets Trigger OAuth2**
2. Autenticá con tu cuenta de Google
3. Asigná la credencial al nodo **Google Sheets Trigger**
4. Seleccioná tu hoja de cálculo y la hoja **Hoja 1**

### 4. Configurar la API Key de Gemini
1. Obtené tu API Key en https://aistudio.google.com → Get API Key
2. En los nodos **HTTP clasificador gemini-2.5-flash** y **LLM Explicador geminiPRO**,
   reemplazá `TU_API_KEY_AQUI` en la URL por tu key real

### 5. Configurar el email SMTP (Gmail)
1. En tu cuenta Google → Seguridad → Verificación en 2 pasos → Activar
2. Seguridad → **Contraseñas de aplicaciones** → generá una para "Correo"
3. En n8n → **Credentials** → **New** → **SMTP**:
   - **User:** tu@gmail.com
   - **Password:** la clave de 16 caracteres generada
   - **Host:** smtp.gmail.com
   - **Port:** 465
   - **SSL/TLS:** ON
4. Asigná la credencial a los nodos **Enviar Alerta Email** y **Notificar Error**
5. En ambos nodos actualizá el campo **To Email** con tu email de destino

### 6. Activar el workflow
1. Hacé click en el toggle de activación arriba a la derecha → **Publish**
2. El workflow va a revisar la hoja cada minuto en busca de filas nuevas

---

## Cómo probar

1. Abrí la Google Sheet
2. Agregá una fila nueva con estos datos de ejemplo:

| tweet_text | autor | fecha |
|---|---|---|
| me encanta el servicio | micaela | 01/04/2026 |
| no me gusta para nada | carlos | 01/04/2026 |
| me da lo mismo | brian | 01/04/2026 |

3. Esperá hasta 1 minuto
4. Para el tweet negativo vas a recibir un email con el análisis completo
5. Podés ver las ejecuciones en n8n → **Executions**

---

## Notas de seguridad

- No se suben credenciales reales en el workflow.json — reemplazo las API keys por `TU_API_KEY_AQUI`
- La contraseña de aplicación de Gmail es específica para esta app y se puede revocar en cualquier momento
- Las credenciales se gestionan desde el panel de n8n y no se exportan en el workflow.json
